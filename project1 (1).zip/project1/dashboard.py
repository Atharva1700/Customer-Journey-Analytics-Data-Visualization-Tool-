"""Interactive Plotly Dashboard for Customer Journey Analytics"""
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import pandas as pd

def create_funnel_chart(funnel_data: dict) -> go.Figure:
    """Create funnel visualization from drop-off data."""
    stages = list(funnel_data.keys())
    values = list(funnel_data.values())

    fig = go.Figure(go.Funnel(
        y=stages,
        x=values,
        marker=dict(color=['#636EFA', '#EF553B', '#00CC96', '#AB63FA'])
    ))
    fig.update_layout(
        title='Customer Journey Funnel',
        height=400,
        font=dict(size=12)
    )
    return fig

def create_cohort_heatmap(cohort_data: pd.DataFrame) -> go.Figure:
    """Create cohort retention heatmap."""
    fig = go.Figure(data=go.Heatmap(
        z=cohort_data.values,
        x=cohort_data.columns,
        y=cohort_data.index,
        colorscale='Viridis'
    ))
    fig.update_layout(
        title='Cohort Retention Analysis',
        xaxis_title='Weeks Since Signup',
        yaxis_title='Cohort',
        height=400
    )
    return fig

def create_dashboard(analytics) -> go.Figure:
    """Combine multiple visualizations."""
    funnel_data = analytics.funnel_analysis(['page_view', 'click', 'signup', 'purchase'])
    conv_rate = analytics.conversion_rate('purchase')

    fig = make_subplots(
        rows=2, cols=2,
        subplot_titles=('Funnel', f'Conversion Rate: {conv_rate:.1f}%', 'Top Paths', 'Time to Conversion'),
        specs=[[{'type': 'bar'}, {'type': 'indicator'}],
               [{'type': 'bar'}, {'type': 'histogram'}]]
    )

    # Funnel
    fig.add_trace(
        go.Bar(x=list(funnel_data.values()), y=list(funnel_data.keys()), orientation='h'),
        row=1, col=1
    )

    # KPI
    fig.add_trace(
        go.Indicator(value=conv_rate, mode='gauge+number', title='Conversion %'),
        row=1, col=2
    )

    fig.update_layout(height=700, title_text='Customer Journey Dashboard', showlegend=False)
    return fig
