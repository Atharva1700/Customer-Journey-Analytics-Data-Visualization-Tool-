"""Customer Journey Analytics Engine"""
import pandas as pd
from typing import Dict, List
from datetime import datetime
import json

class CustomerJourney:
    def __init__(self, customer_id: str, events: List[Dict]):
        self.customer_id = customer_id
        self.events = sorted(events, key=lambda x: x['timestamp'])
        self.journey_path = [e['event_type'] for e in self.events]

    def funnel_position(self, funnel_stages: List[str]) -> int:
        """Find how far customer progressed in funnel."""
        for i, stage in enumerate(funnel_stages):
            if stage not in self.journey_path:
                return i
        return len(funnel_stages)

    def time_to_conversion(self) -> float:
        """Hours from first to last event."""
        if len(self.events) < 2:
            return 0
        first = datetime.fromisoformat(self.events[0]['timestamp'])
        last = datetime.fromisoformat(self.events[-1]['timestamp'])
        return (last - first).total_seconds() / 3600

class JourneyAnalytics:
    def __init__(self, df: pd.DataFrame):
        """df columns: customer_id, event_type, timestamp, properties (json)"""
        self.df = df
        self.journeys = self._build_journeys()

    def _build_journeys(self) -> Dict[str, CustomerJourney]:
        journeys = {}
        for cid, group in self.df.groupby('customer_id'):
            events = group[['event_type', 'timestamp', 'properties']].to_dict('records')
            journeys[cid] = CustomerJourney(cid, events)
        return journeys

    def funnel_analysis(self, stages: List[str]) -> Dict:
        """Analyze drop-off at each funnel stage."""
        results = {stage: 0 for stage in stages}
        for journey in self.journeys.values():
            pos = journey.funnel_position(stages)
            if pos > 0:
                results[stages[pos - 1]] += 1
        return results

    def cohort_filter(self, property_key: str, value: str) -> List[str]:
        """Return customer IDs matching property filter."""
        filtered = self.df[
            self.df['properties'].str.contains(f'"{property_key}".*"{value}"', regex=True)
        ]['customer_id'].unique()
        return list(filtered)

    def conversion_rate(self, conversion_event: str) -> float:
        """% of customers with conversion event."""
        converted = sum(1 for j in self.journeys.values()
                       if conversion_event in j.journey_path)
        return converted / len(self.journeys) * 100 if self.journeys else 0

# Example usage
if __name__ == '__main__':
    sample_data = pd.DataFrame([
        {'customer_id': 'c1', 'event_type': 'page_view', 'timestamp': '2026-01-01T10:00:00', 'properties': '{"page":"home"}'},
        {'customer_id': 'c1', 'event_type': 'click', 'timestamp': '2026-01-01T10:05:00', 'properties': '{"button":"signup"}'},
        {'customer_id': 'c1', 'event_type': 'signup', 'timestamp': '2026-01-01T10:10:00', 'properties': '{"plan":"free"}'},
        {'customer_id': 'c2', 'event_type': 'page_view', 'timestamp': '2026-01-01T10:00:00', 'properties': '{"page":"home"}'},
        {'customer_id': 'c2', 'event_type': 'click', 'timestamp': '2026-01-01T10:05:00', 'properties': '{"button":"close"}'},
    ])

    analytics = JourneyAnalytics(sample_data)
    funnel = analytics.funnel_analysis(['page_view', 'click', 'signup', 'purchase'])
    print(f"Funnel: {funnel}")
    print(f"Conversion Rate: {analytics.conversion_rate('signup'):.1f}%")
